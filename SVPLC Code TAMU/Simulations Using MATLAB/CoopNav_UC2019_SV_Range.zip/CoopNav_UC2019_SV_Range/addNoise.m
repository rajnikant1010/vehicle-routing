function [VelocityVectorwithNoise,PsiDotVectorwithNoise]=addNoise(VelocityVector,PsiDotVector,P1)
% This function adds noise to the the velcity and turn rate of all the
% vectors
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
VelocityVectorwithNoise=VelocityVector+randn(P1.N,1)*P1.Vn;
PsiDotVectorwithNoise=PsiDotVector+randn(P1.N,1)*P1.Xn;