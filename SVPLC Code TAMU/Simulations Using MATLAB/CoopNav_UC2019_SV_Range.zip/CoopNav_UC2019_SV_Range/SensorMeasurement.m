function [MeasurementMatrix1,MeasurementMatrix2]=SensorMeasurement(P1,X,XL,j)
% Bearing measurement sensor
% this function finds the bearing form other vechicles and landmarks for j
% th vehicle
% --------Input------------------------------------------------------------
% X-n vehicle state  vector  size=3n
% j- vehicle index
% P1- Simulation parmaeter structure
% XL- landmark state vector
%--------Output------------------------------------------------------------
% MeasurementMatrix1- Inter vehicle bearing measurement matrix
% MeasurementMatrix2- Landamerk bearing measurent matrix
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
X1=X(3*(j-1)+1:3*(j-1)+3,1);
x1=X1(1);
y1=X1(2);
si1=X1(3);
Xreshaped=reshape(X,3,P1.N);
dx1=Xreshaped(1,:)-x1;
dy1=Xreshaped(2,:)-y1;
dist1=(dx1.^2+dy1.^2).^0.5;
dist1(j)=P1.Rsensor+100;
row1=find(dist1<=P1.Rsensor);
if (isempty(row1)==1)
 MeasurementMatrix1=[];
else
MeasurementMatrix1=zeros(size(row1,1),3);
for i=1:size(row1,2)
    
    % For IV Range Meas
    rng_meas = (dx1.^2+dy1.^2).^0.5 + randn(1)*P1.sig_rho;
    MeasurementMatrix1(i,:)=[rng_meas,row1(i),1];
    
    % For IV Bearing Meas
    % eta=atan2(dy1(row1(i)),dx1(row1(i)))-si1;
    % eta = pi_to_pi(eta)+randn(1)*P1.sig_eta;
    % MeasurementMatrix1(i,:)=[eta,row1(i),1];
end
end

XLreshaped=reshape(XL,2,P1.N2);
dx2=XLreshaped(1,:)-x1;
dy2=XLreshaped(2,:)-y1;
dist2=(dx2.^2+dy2.^2).^0.5;
row2=find(dist2<=P1.Rsensor);
% Using J you can decide which vehicles see the landmarks
if(isempty(row2)==1 || j>P1.N)
    MeasurementMatrix2=[];
else
    
MeasurementMatrix2 = zeros(size(row2,1),3);
rho = dist2(row2) + randn(1)*P1.sig_rho;

for i=1:size(row2,2)
    % For bearing meas
    eta = atan2(dy2(row2(i)),dx2(row2(i)))-si1;
    eta = pi_to_pi(eta)+randn(1)*P1.sig_eta;
            
    if ((eta >= -P1.FOV)&&(eta <= P1.FOV))
        % For Bearing Measurement
        % MeasurementMatrix2(i,:)=[eta,row2(i),1];
        
        % For Range Measurement
        MeasurementMatrix2(i,:)=[rho(i), row2(i),1];
    end
end

MeasurementMatrix2( ~any(MeasurementMatrix2,2), : ) = [];

end
