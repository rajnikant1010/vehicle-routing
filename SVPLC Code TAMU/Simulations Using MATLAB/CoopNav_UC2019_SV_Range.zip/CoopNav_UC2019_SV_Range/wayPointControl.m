function [PsiDotC,currentWaypoint]=wayPointControl(P1,currentWaypoint, XV,j)

%WAYPOINTCONTROL this gives the turn rate vector given waypoints and vehicle states
% velocity
%-----------Input--------------
% P1- parameters
% currentWaypoint- waypoint Index for vehicle j
% j- vehicle index
% XV - jth vehicle postion
%---------output---------------
% PsiDotC- computed turnrate command
% currentWaypoint- updated waypoint index
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
xw=P1.Xwp(j,currentWaypoint);
yw=P1.Ywp(j,currentWaypoint);
x=XV(1);
y=XV(2);
Psi=XV(3);
psiD=atan2(yw-y,xw-x);
PsiDotC=P1.K*(pi_to_pi(psiD-Psi));
R=((xw-x)^2+(yw-y)^2)^0.5;
if (R<P1.minDis)
  if (currentWaypoint==P1.Nwp)
      currentWaypoint=1;
  else
    currentWaypoint=currentWaypoint+1;
  end
end
