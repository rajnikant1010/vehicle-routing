function p= make_feature_covariance_ellipses(xx,PP)

% compute ellipses for plotting feature covariances
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
N= 50;
inc= 2*pi/N;
phi= 0:inc:2*pi;
circ= 2*[cos(phi); sin(phi)];

lenx= length(xx);
lenf= (lenx)/3;
p= zeros (2, lenf*(N+2));

ctr= 1;
for i=1:lenf
    ii= ctr:(ctr+N+1);
    jj= 3*(i-1)+1; jj= jj:jj+1;
    
    p(:,ii)= make_ellipse(xx(jj), PP(jj,jj), circ);
    ctr= ctr+N+2;
end