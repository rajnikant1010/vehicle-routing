function [h]=plotVehicle(h,X1filter,X1true,P1,pvcov)
%PLOTVEHICLE plots the RPMG

set(h.VehicleActual,'xdata',X1true(1,:),'ydata',X1true(2,:));
set(h.VehicleFilter,'xdata',X1filter(1,:),'ydata',X1filter(2,:));
set(h.vcov, 'xdata', pvcov(1,:), 'ydata', pvcov(2,:))
drawnow;





