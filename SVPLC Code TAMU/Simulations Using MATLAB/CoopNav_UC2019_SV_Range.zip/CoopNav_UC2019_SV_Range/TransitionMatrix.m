function F=TransitionMatrix(X0,VelVector,Ts,P1)
%%Computes system jacobian for N vehicles
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
F=zeros(3*P1.N);
for i=1:P1.N
    F(3*(i-1)+1:3*(i-1)+3,3*(i-1)+1:3*(i-1)+3)=SingleVehicleTransMatrix(X0(3*(i-1)+1:3*(i-1)+3),VelVector(i),Ts);
end
function Fsingle=SingleVehicleTransMatrix(X0s,V,Ts)
x=X0s(1);
y=X0s(2);
psi=X0s(3);
Fu=zeros(3);
Fu(1,3)=-V*sin(psi);
Fu(2,3)=V*cos(psi);
Fsingle=eye(3)+Ts*Fu;