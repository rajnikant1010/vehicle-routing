function [X]=SingleVehicleModel(X0,Ts,V,sidot)
%SINGLEVEHICLEMODEL Thsi function fredicts the next single vehicle state given previous
% --------Input------------------------------------------------------------
% X0-n vehicle state  vector  size=3n

% Ts- Sampling Time

% V- velocity
% siDot- turn rate
% 
%--------Output------------------------------------------------------------
% X- predicted single vehicle state
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
x=X0(1,1);
y=X0(2,1);
psi=X0(3,1);

fx=[...
    V*cos(psi);....
    V*sin(psi);...
    sidot];
X=X0+Ts*fx;
