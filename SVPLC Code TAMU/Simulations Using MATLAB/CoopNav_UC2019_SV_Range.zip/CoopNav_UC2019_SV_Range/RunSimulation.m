function RunSimulation(P1)
%RUNSIMULATION main function 
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
close all
%% change
iter = P1.iter;
%iter=10000;
si0a = P1.si0;

display('Run Vehicle using True (0) or Estimated (1) data');
vehicleRun = input('Enter desired option: ');

% ith uav state xx0a(:,i)
Xt=[P1.x0a
    P1.y0a
    si0a];
Xtrue=reshape(Xt,3*P1.N,1);
% ith anchor state xxs0(:,i);


XL2=[P1.xxs
    P1.yys];
XL=reshape(XL2,2*P1.N2,1);
%% EKF state initialization
x0a1=P1.x0a+randn(1)*P1.sx;
y0a1=P1.y0a+randn(1)*P1.sy;
si0a1=si0a+randn(1)*P1.sTheta;

Xf=[x0a1
    y0a1
    si0a1];
Xfilter=reshape(Xf,3*P1.N,1);

Ximu=Xfilter;
P0=zeros(3*P1.N);
for i=1:P1.N %covariance Initialization
    P0(3*(i-1)+1,3*(i-1)+1)=P1.sx^2;
    P0(3*(i-1)+2,3*(i-1)+2)=P1.sy^2;
    P0(3*(i-1)+3,3*(i-1)+3)=P1.sTheta^2;
end
Pfilter=P0;
% Velocity and turnrate noise

Rmeas=P1.sig_eta^2;
PlotColor='ro';

h=SetupAnimationForVehicle(P1,XL2,PlotColor);
figure(2)
for i=1:P1.N
h2(i)=line(0,0,'Color','c','LineWidth',1,'LineStyle','--','EraseMode','xor');
end
%%
%%main loop

currentWaypoint=ones(P1.N,1);
PsiDotVector=zeros(P1.N,1);
VelocityVector=ones(P1.N,1)*P1.V;

Data.XfilterData=zeros(3*P1.N,iter);
Data.XtrueData=zeros(3*P1.N,iter);
Data.CovarainceData=zeros(3*P1.N,iter);
Data.time=zeros(1,iter);
% uncomment for writinng a avi file
%mov = avifile('CNS2.avi', 'fps', 5, 'quality', 100,'compression', 'none') ;
for i=1:iter
    XXt=reshape(Xtrue,3,P1.N);
    xplot=XXt(1,:)';
    yplot=XXt(2,:)';
%     for j=1:P1.N
%     set(h2(j), 'xdata', xplot, 'ydata', yplot)
%     end
%drawnow;
    Data.time(i)=(i-1)*P1.Ts;
    % store Data
    Data.XfilterData(:,i)=Xfilter;
    Data.XtrueData(:,i)=Xtrue;
    Data.CovarainceData(:,i)=diag(Pfilter).^0.5;

     pfcov = make_feature_covariance_ellipses(Xfilter,Pfilter);
     [h] = plotVehicle(h,reshape(Xfilter,3,P1.N),reshape(Xtrue,3,P1.N),P1,pfcov);
    %
    % find control
    % vehicleRun = 0; % True by default

    for j=1:P1.N
        switch(vehicleRun)
            case 0
                [PsiDotVector(j,1),currentWaypoint(j,1)]= wayPointControl(P1,currentWaypoint(j,1), Xtrue(3*(j-1)+1:3*(j-1)+3,1),j)  ;
            case 1
                [PsiDotVector(j,1),currentWaypoint(j,1)]= wayPointControl(P1,currentWaypoint(j,1), Xfilter(3*(j-1)+1:3*(j-1)+3,1),j);
            otherwise
                [PsiDotVector(j,1),currentWaypoint(j,1)]= wayPointControl(P1,currentWaypoint(j,1), Xtrue(3*(j-1)+1:3*(j-1)+3,1),j)  ;
        end
    end
    % add noise
    [VelocityVectorwithNoise,PsiDotVectorwithNoise]=addNoise(VelocityVector,PsiDotVector,P1);
    % predict true
    Xtrue=predictNvehicleState(Xtrue,VelocityVector,PsiDotVector,P1.Ts,P1);
    % predict IMU
    Ximu=predictNvehicleState(Ximu,VelocityVectorwithNoise,PsiDotVectorwithNoise,P1.Ts,P1);
    % predict EKF
    [Xfilter,Pfilter,h2]=CnsEKF(Xfilter,Pfilter,P1.Ts,P1,VelocityVectorwithNoise,PsiDotVectorwithNoise,Xtrue,XL,h2);
% % uncomment for writinng a avi file 
% h3(i)=getframe;
%  mov = addframe(mov,h3(i)); 

end
% % uncomment for writinng a avi file
%mov = close(mov);
%%%% Error Plots
for j=1:P1.N
    figure(3+j)
    
    subplot(3,1,1)
    plot(Data.time,Data.XtrueData(3*(j-1)+1,:)-Data.XfilterData(3*(j-1)+1,:),'r',Data.time,3*Data.CovarainceData(3*(j-1)+1,:),'b',Data.time,-3*Data.CovarainceData(3*(j-1)+1,:),'b')
    legend('Error_x','+3\sigma_x','-3\sigma_x');
    xlabel('Time(s)');
    ylabel('Error in X (m)');
    grid on
    
    subplot(3,1,2)
    plot(Data.time,Data.XtrueData(3*(j-1)+2,:)-Data.XfilterData(3*(j-1)+2,:),'r',Data.time,3*Data.CovarainceData(3*(j-1)+2,:),'b',Data.time,-3*Data.CovarainceData(3*(j-1)+2,:),'b')
    legend('Error_y','+3\sigma_y','-3\sigma_y');
    xlabel('Time(s)');
    ylabel('Error in Y (m)');
    grid on
    
    subplot(3,1,3)
    plot(Data.time,Data.XtrueData(3*(j-1)+3,:)-Data.XfilterData(3*(j-1)+3,:),'r',Data.time,3*Data.CovarainceData(3*(j-1)+3,:),'b',Data.time,-3*Data.CovarainceData(3*(j-1)+3,:),'b')
    legend('Error_{\psi}','+3\sigma_{\psi}','-3\sigma_{\psi}');
    xlabel('Time(s)');
    ylabel('Error in \psi (rad)');
    grid on
end

figure(4+P1.N)
ph1 = plot(P1.x0a, P1.y0a,'kp');
hold on
for j=1:P1.Nwp
    ph4 = plot(P1.Xwp(1,j),P1.Ywp(1,j),'bd');
    text(P1.Xwp(1,j)+0.1,P1.Ywp(1,j)+0.1,int2str(j));
    hold on
end

for j=1:P1.N2
    ph5 = plot(P1.xxs(1,j),P1.yys(1,j),'ks');
    text(P1.xxs(1,j)-0.2,P1.yys(1,j)+0.1,int2str(j));
    hold on
end
ph2 = plot(Data.XfilterData(1,:),Data.XfilterData(2,:),'--b','Linewidth',1.2);
hold on
ph3 = plot(Data.XtrueData(1,:),  Data.XtrueData(2,:),  '-r', 'Linewidth',1.2);
grid on
legend([ph1, ph2, ph3, ph4, ph5],'Start Point','Filter Data','True Data','Waypoints','Landmarks','Location','southwest');
xlabel('X-Axis');
ylabel('Y-Axis');
axis([P1.Xmin-P1.buf, P1.Xmax+P1.buf, P1.Ymin-P1.buf, P1.Ymax+P1.buf]);

save('SimCompData.mat','P1','Data');

