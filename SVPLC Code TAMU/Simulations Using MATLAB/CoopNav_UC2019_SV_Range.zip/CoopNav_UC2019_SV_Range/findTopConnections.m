function [xl,yl]=findTopConnections(X,XL,M1,M2,P1,i)
% this function plots the inter vehicle and bearing conncetions
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
X1=X(3*(i-1)+1:3*(i-1)+3);

xl=[];
yl=[];

if(isempty(M1)==0)
    for k=1:size(M1,1)
        j=M1(k,2);
        X2=zeros(3,1);
        X2=X(3*(j-1)+1:3*(j-1)+3,1);
        xx=[X1(1) X2(1)];
        yy=[X1(2) X2(2)];
        xl=[xl xx];
        yl=[yl yy];
    end
end

if(isempty(M2)==0)
    for k=1:size(M2,1)
        clear X2;
        j=M2(k,2);
        X2=XL(2*(j-1)+1:2*(j-1)+2,1);
        xx=[X1(1) X2(1)];
        yy=[X1(2) X2(2)];
        xl=[xl xx];
        yl=[yl yy];
    end
end
