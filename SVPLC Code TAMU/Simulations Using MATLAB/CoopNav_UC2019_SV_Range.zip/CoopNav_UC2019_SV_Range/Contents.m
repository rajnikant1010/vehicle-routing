% COOPNAVSYS_BYU2009
%
% Files
%   addNoise                         - This function adds noise to the the velcity and turn rate of all the
%   CnsEKF                           - 
%   ComputeVehicleInforMatVec        - 1 is bearing measurement 2 is vehicle or landamrk index
%   findTopConnections               - this function plots the inter vehicle and bearing conncetions
%   InterVehicleLandMarkJac          - i is vehicle index
%   InterVehicleMeasurementJac       - i vehicle with sensor
%   make_ellipse                     - make a single 2-D ellipse
%   make_feature_covariance_ellipses - compute ellipses for plotting feature covariances
%   make_vehicle_covariance_ellipse  - compute ellipses for plotting vehicle covariances
%   param                            - parameter file
%   pi_to_pi                         - Input: array of angles.
%   plotVehicle                      - plots the RPMG
%   predictCovariance                - predicts covariance
%   predictNvehicleState             - this function predicts the state for all N vehicles togethet can be used
%   processNoise                     -  finds the process noise
%   RunSimulation                    - main function 
%   SensorMeasurement                - Bearing measurement sensor
%   SetupAnimationForVehicle         - sets up plots
%   SingleVehicleModel               - Thsi function fredicts the next single vehicle state given previous
%   sqrtm_2by2                       - SQRTM     Matrix square root.
%   TransitionMatrix                 - Computes system jacobian for N vehicles
%   wayPointControl                  -  this gives the turn rate vector given waypoints and vehicle states
