function X=predictNvehicleState(X0,VelVector,PsiDotVector,Ts,P1)
%PREDICTNVEHICLESTATE this function predicts the state for all N vehicles togethet can be used
% --------Input------------------------------------------------------------
% X0-n vehicle state  vector  size=3n
% Ts- Sampling Time
% P1- Simulation parmaeter structure
% VelocityVector- contains velocity of all the vehicles from encoders
% PsiDotVector- contains turnrate of all vehicles from encoders (path planning)

%--------Output------------------------------------------------------------
% X- predicted vehicle state vector

%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------

X=zeros(3*P1.N,1);
for i=1:P1.N
 X(3*(i-1)+1: 3*(i-1)+3,1)=SingleVehicleModel(X0(3*(i-1)+1: 3*(i-1)+3,1),Ts,VelVector(i),PsiDotVector(i)) ; 
end
