function p= make_ellipse(xx,PP,circ)
% make a single 2-D ellipse
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
r=3*sqrtm_2by2(PP);
a= r*circ;
p(2,:)= [a(2,:)+xx(2) NaN];
p(1,:)= [a(1,:)+xx(1) NaN];