function [It,it]=ComputeVehicleInforMatVec(P1,CmpMatInterVeh,CmpMatLM,X,XL,i,X0)
%COMPUTEVEHICLEINFORMATVEC 1 is bearing measurement 2 is vehicle or landamrk index
% --------Input------------------------------------------------------------
% X0-n vehicle state  vector  size=3n--before prediction
% X- n vehicle state after prediction step
% Ts- Sampling Time
% P1- Simulation parmaeter structure
% CmpMatInterVeh- Inter vehicle bearing/range Measurementment matrix ist column is
% bearing secnd column is index of vehicles
% CmpMatLM- bearing/range measurementment matrix ist column is
% bearing second column is index landmarks
% i-vehicle index
% XL- landmark state vector
%
%--------Output------------------------------------------------------------
% It- Inforamtion matrix of vehicle i
% it-information vector of vehicle i
% handle for plotting bearing connections in RPMG
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Sohum Misra on 14-Jan-2019
%--------------------------------------------------------------------------
Iv=zeros(3*P1.N);
iv=zeros(3*P1.N,1);
% LMMmatrix
Ilm=zeros(3*P1.N);
ilm=zeros(3*P1.N,1);
Rmeas=P1.sig_eta^2;
if(isempty(CmpMatInterVeh)==0)
    for k=1:size(CmpMatInterVeh,1)
        j=CmpMatInterVeh(k,2);
        H=InterVehicleMeasurementJac(X0,i,j,P1);
        Iv=Iv+H'*Rmeas^(-1)*H;
        X1=X(3*(i-1)+1:3*(i-1)+3,1);
        X2=X(3*(j-1)+1:3*(j-1)+3,1);
        
        % eta_est=bearingMeas(X1,X2);
        % eta=CmpMatInterVeh(k,1);
        % mu=pi_to_pi(eta-eta_est);
        
        rho_est = rangeMeas(X1,X2);
        rho     = CmpMatInterVeh(k,1);
        mu      = rho - rho_est;
        
        iv=iv+H'*Rmeas^(-1)*((mu)+H*X);
        
    end
end

if(isempty(CmpMatLM)==0)
    for k=1:size(CmpMatLM,1)
        j=CmpMatLM(k,2);
        H=InterVehicleLandMarkJac(X0,XL,i,j,P1);
        Ilm=Ilm+H'*Rmeas^(-1)*H;
        X1=X(3*(i-1)+1:3*(i-1)+3,1);
        X2=XL(2*(j-1)+1:2*(j-1)+2,1);
        
        % eta_est=bearingMeas(X1,X2);
        % eta=CmpMatLM(k,1);
        % mu=pi_to_pi(eta-eta_est);
        
        rho_est = rangeMeas(X1,X2);
        rho     = CmpMatLM(k,1);
        mu      = rho - rho_est;
        
        ilm=ilm+H'*Rmeas^(-1)*((mu)+H*X);
        
    end
end

It=Iv+Ilm;
it=iv+ilm;

end

function eta=bearingMeas(X1,X2)
x1=X1(1);
y1=X1(2);
psi1=X1(3);

x2=X2(1);
y2=X2(2);

eta=atan2(y2-y1,x2-x1)-psi1;
eta = pi_to_pi(eta);
end

function rho=rangeMeas(X1,X2)
x1=X1(1);
y1=X1(2);

x2=X2(1);
y2=X2(2);

rho =  ((x1-x2)^2+(y1-y2)^2)^0.5;
end
