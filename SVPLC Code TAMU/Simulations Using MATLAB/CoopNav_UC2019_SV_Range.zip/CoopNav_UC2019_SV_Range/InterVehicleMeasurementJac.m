function [H]=InterVehicleMeasurementJac(X0,i,j,P1)
% i vehicle with sensor
% j object vehicle
X01=X0(3*(i-1)+1:3*(i-1)+3,1);
X02=X0(3*(j-1)+1:3*(j-1)+3,1);
x1=X01(1);
y1=X01(2);
%si1=X0(3);
x2=X02(1);
y2=X02(2);
H1 =[ (y2-y1)/((x2-x1)^2+(y2-y1)^2), -(x2-x1)/((x2-x1)^2+(y2-y1)^2), -1, -(y2-y1)/((x2-x1)^2+(y2-y1)^2), (x2-x1)/((x2-x1)^2+(y2-y1)^2),  0];
H=zeros(1,3*P1.N);
H(1,3*(i-1)+1:3*(i-1)+3)=H1(1,1:3);
H(1,3*(j-1)+1:3*(j-1)+3)=H1(1,4:6);
