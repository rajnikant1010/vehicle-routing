function h=SetupAnimationForVehicle(P1,XL,PlotColor)
%SETUPANIMATIONFORVEHICLE sets up plots
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
figure(2);
% plot landmarks
hLM = plot(XL(1,:),XL(2,:),'ks','markersize',15);
grid on
axis([P1.Xmin P1.Xmax P1.Ymin P1.Ymax])
hold on
scatter(P1.Xwp,P1.Ywp);
hold on
for i=1:P1.N2
    text(XL(1,i)+0.1,XL(2,i),int2str(i));
end
h.vcov=plot(0,0,'b','erasemode','xor');
hold on
h.VehicleActual=plot(0,0,'ro','markersize',6,'linewidth',2,'erasemode','xor');
hold on
h.VehicleFilter=plot(0,0,'kd','markersize',6,'linewidth',2,'erasemode','xor');
grid on
xlabel('X(m)');
ylabel('Y(m)');
legend([hLM, h.vcov, h.VehicleActual, h.VehicleFilter],'LM','3\sigma','True','Filter');
