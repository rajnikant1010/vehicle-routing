function [Xfilter,Pfilter,h2]=CnsEKF(X0,P0,Ts,P1,VelocityVector,PsiDotVector,Xtrue,XL,h2)
%CNSEKF 
% --------Input------------------------------------------------------------
% X0-n vehicle state  vector  size=3n
% P0- Previous Vehicle covariance matrix
% Ts- Sampling Time
% P1- Simulation parmaeter structure
% VelocityVector- contains velocity of all the vehicles from encoders
% PsiDot- contains turnrate of all vehicles from encoders (path planning)
% Xtrue - true state of vehicles for generating the true measurements
% XL- landmark state vector
% h2-handle for ploting bearing connections in the network
%--------Output------------------------------------------------------------
% Xfilter- updated vehicle state vector
% Pfilter-updated vehicle covariance matrix
% handle for plotting bearing connections in RPMG
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
%% Begin

Xfilter=X0;
Pfilter=P0;
% find process noise
Q1=[P1.Vn^2 0
    0 P1.Xn^2];
Q=processNoise(Q1,Xfilter,Ts,P1);
% Find Transition Matrix
F=TransitionMatrix(Xfilter,VelocityVector,Ts,P1);
%% Prediction Step
% Prediction of vehicle state
Xfilter=predictNvehicleState(Xfilter,VelocityVector,PsiDotVector,Ts,P1);
% Predict vehicle Covariance
Pfilter=predictCovariance(Pfilter,F,Q);
%% Update Step
%SensorMeasurement
Ytotal=zeros(3*P1.N);
ytotal=zeros(3*P1.N,1);
for i=1:P1.N

    [MeasurementMatrix1,MeasurementMatrix2]=SensorMeasurement(P1,Xtrue,XL,i);
    [xl,yl]=findTopConnections(Xtrue,XL,MeasurementMatrix1,MeasurementMatrix2,P1,i);
    set(h2(i), 'xdata', xl, 'ydata', yl);
    drawnow;
    [It,it]=ComputeVehicleInforMatVec(P1,MeasurementMatrix1,MeasurementMatrix2,Xfilter,XL,i,X0);
    Ytotal=Ytotal+It;
    ytotal=ytotal+it;
end
% adding measurement information form varios vehicles
Ybar=Pfilter^-1;
ybar=Ybar*Xfilter;
Ybar=Ybar+Ytotal;
ybar=ybar+ytotal;

Pfilter=Ybar^-1;
Xfilter=Pfilter*ybar;
%% End
