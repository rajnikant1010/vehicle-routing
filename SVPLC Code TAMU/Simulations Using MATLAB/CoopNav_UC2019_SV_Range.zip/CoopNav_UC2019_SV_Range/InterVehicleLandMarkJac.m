function [H]=InterVehicleLandMarkJac(X0,XL,i,j,P1)
% i is vehicle index
% j is landmark
X01=X0(3*(i-1)+1:3*(i-1)+3,1);
x1=X01(1,1);
y1=X01(2,1);
X02=XL(2*(j-1)+1:2*(j-1)+2,1);
x2=X02(1,1);
y2=X02(2,1);
% For Bearing
% H2 =[ (y2-y1)/((x2-x1)^2+(y2-y1)^2), -(x2-x1)/((x2-x1)^2+(y2-y1)^2), -1, 0, 0, 0];

% For Range

den = ((x2-x1)^2+(y2-y1)^2)^(0.5);

H2 =[ (x1-x2)/den, (y1-y2)/den, 0, 0, 0, 0];

H=zeros(1,3*P1.N);
H(1,3*(i-1)+1:3*(i-1)+3)=H2(1,1:3);
%H(1,3*(j-1)+1:3*(j-1)+3)=H2(1,4:6);