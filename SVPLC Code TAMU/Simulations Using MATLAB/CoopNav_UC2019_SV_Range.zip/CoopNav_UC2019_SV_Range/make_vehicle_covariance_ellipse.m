function p= make_vehicle_covariance_ellipse(xx,PP)
% compute ellipses for plotting vehicle covariances
N= 50;
inc= 2*pi/N;
phi= 0:inc:2*pi;
circ= 2*[cos(phi); sin(phi)];

p= make_ellipse(xx(1:2), PP(1:2,1:2), circ);