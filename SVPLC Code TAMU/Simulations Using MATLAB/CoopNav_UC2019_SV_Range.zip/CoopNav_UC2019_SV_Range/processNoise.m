function Q=processNoise(Q1,X0,Ts,P1)
%PROCESSNOISE finds the process noise
%% ------Bearing only cooperative navigation system------------------------
%  MAGICC LAB, Department of Electrical and Computer Engineering,
%  Brigham Young University, Provo
%  Authors: Rajnikant Sharma :  raj.drdo@gmail.com
%           Clark N.Taylor   :  clark.taylor@byu.edu
%  Last Updated: Rajnikant Sharma Oct 12 2009. 
%--------------------------------------------------------------------------
Q=zeros(3*P1.N);
for i=1:P1.N
     Q(3*(i-1)+1:3*(i-1)+3,3*(i-1)+1:3*(i-1)+3)=SingleVehicleNoise(Q1,X0(3*(i-1)+1:3*(i-1)+3,1),Ts);
end
function Qs=SingleVehicleNoise(Q1,X1,Ts)

psi=X1(3);
Fn=Ts*[...
    cos(psi) 0;...
    sin(psi) 0;...
    0 1];
Qs=Fn*Q1*Fn';
